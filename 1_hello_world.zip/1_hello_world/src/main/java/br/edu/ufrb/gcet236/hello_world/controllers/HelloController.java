package br.edu.ufrb.gcet236.hello_world.controllers;

import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ufrb.gcet236.hello_world.mundo_animal.Crocodilo;

/**
* ExampleController
* 
* @author Daniel Padua
*/
@RestController
@RequestMapping("api")
public class HelloController {

    @GetMapping("/hello-world")
    public ResponseEntity<String> get() {
        return ResponseEntity.ok("Hello World!");
    }

    @GetMapping("/hello")
    public ResponseEntity<String> get(@RequestParam Optional<String> nome) {
        String nomeASerApresentado = "Fulano";
        if (nome.isPresent()) {
            nomeASerApresentado = nome.get();
        }
        return ResponseEntity.ok("Olá " + nomeASerApresentado + "!");
    }

    @GetMapping("/crocodilo")
    public ResponseEntity<String> crocodilo() {
        Crocodilo crocodiloDundee = new Crocodilo();
        System.out.println(crocodiloDundee.getCor());
        crocodiloDundee.setCor("vermelho");
        System.out.println(crocodiloDundee.getCor());
        
        return ResponseEntity.ok("Hello World!");
    }

}